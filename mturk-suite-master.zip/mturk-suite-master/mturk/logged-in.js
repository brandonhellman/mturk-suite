chrome.runtime.sendMessage({ loggedIn: true });
